﻿/* Copyright (C) Ali Deym - All Rights Reserved
 * Unauthorized copying and/or modifying of this file, via any medium is strictly prohibited.
 * Proprietary and confidential.
 * Written by Ali Deym <ali.deym.gm@gmail.com>, 2017-2018
 */

using System;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;

using System.Threading.Tasks;

using libBifler;

namespace Bifler
{
	/// <summary>
	/// Creates a project start form.
	/// </summary>
	public partial class ProjectStartupForm : Form
	{
		private string _projectPath;

		/* Application core. */
		Core appCore = null;

		/// <summary>
		/// Initializes the form.
		/// </summary>
		/// <param name="sender">Application's core.</param>
		public ProjectStartupForm (Core sender)
		{
			_projectPath = "projects/";

			InitializeComponent ();

			appCore = sender;
		}

		private void OnCancellation (object sender, EventArgs e)
		{
			Close ();
		}

		[DllImport ("kernel32.dll", SetLastError = true)]
		[return: MarshalAs (UnmanagedType.Bool)]
		static extern bool AllocConsole ();


		[DllImport ("kernel32", SetLastError = true)]
		static extern bool AttachConsole (int dwProcessId);

		[DllImport ("user32.dll")]
		static extern IntPtr GetForegroundWindow ();

		[DllImport ("user32.dll", SetLastError = true)]
		static extern uint GetWindowThreadProcessId (IntPtr hWnd, out int lpdwProcessId);



		/* Start project button. */
		private void OnStartReaction (object sender, EventArgs e)
		{

			/* Managed folders (categorized) for project. */
			var checkDirs = new [] {
				_projectPath + "\\",
				_projectPath + "\\" + nameBox.Text + "\\",
				_projectPath + "\\" + nameBox.Text + "\\" + provinceBox.Text + "\\",
				_projectPath + "\\" + nameBox.Text + "\\" + provinceBox.Text + "\\" + cityBox.Text + "\\",
				_projectPath + "\\" + nameBox.Text + "\\" + provinceBox.Text + "\\" + cityBox.Text + "\\" + startBox.Text + " - " + finishBox.Text + "\\",
				_projectPath + "\\" + nameBox.Text + "\\" + provinceBox.Text + "\\" + cityBox.Text + "\\" + startBox.Text + " - " + finishBox.Text + "\\" + Language.Lane + " " + projectLane.Value.ToString()
			};

			try {
				for (var i = 0; i < checkDirs.Length; i++) {

					if (!Directory.Exists (checkDirs [i]))
						Directory.CreateDirectory (checkDirs [i]);

				}
			} catch {
				MessageBox.Show (Language.FolderError, Language.Error);
				return;
			}

			var projectFolder = checkDirs [checkDirs.Length - 1];


			appCore.Projects.InitializeProject (codeBox.Text,
				nameBox.Text, startBox.Text, finishBox.Text,
				cityBox.Text, provinceCodeBox.Text, provinceBox.Text,
				directionBox.Text,
				(int)laneBox.Value, appCore.GetGPSData (), (int)startKilometerNumber.Value, appCore.Trigger.Caliber,
				projectFolder);



			appCore.Projects.StartProject ();
			appCore.Trigger.StartTrigger ();



			Close ();
		}

		private void SetPathInvoke (string path)
		{
			if (path == null || String.IsNullOrWhiteSpace (path)) return;

			if (InvokeRequired) {
				Action<string> act = SetPathInvoke;

				Invoke (act, path);

				return;
			}

			_projectPath = path;
			pathBox.Text = path;

			// Set path on config for next uses.
			appCore.MainConfigManager.SetConfig ("ProjectPath", path);
		}

		private void ChooseButtonClick (object sender, EventArgs e)
		{
			/* Create STA Thread, because we're calling OLE objects from COM library which require STA, not MTA. */

			var staThread = new System.Threading.Thread (() => {

				var fd = new FolderBrowserDialog () {
					Description = "Project Folder",
					ShowNewFolderButton = true
				};



				fd.ShowDialog ();


				SetPathInvoke (fd.SelectedPath);
			});

			staThread.SetApartmentState (System.Threading.ApartmentState.STA);
			staThread.Start ();


			

			
		}


		/* Load project path from config. */
		private void FormLoaded (object sender, EventArgs e)
		{
			var configPath = appCore.MainConfigManager.GetConfig ("ProjectPath");

			if (configPath != null && configPath != "") {

				_projectPath = configPath;
				pathBox.Text = configPath;

			}
		}
	}
}
